function Y = year(D)
V = datevec(D);
Y = V(:, 1);
end

